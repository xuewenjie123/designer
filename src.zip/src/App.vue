<template>
	<div id="app">
		<router-view></router-view>
	</div>
</template>

<script>
export default {
	name: "App",
}
</script>

<style>
@import url("//at.alicdn.com/t/font_2102205_tzkthn2ao6m.css");
@import url("./common/common.css");
@import url("./common/font.css");
</style>

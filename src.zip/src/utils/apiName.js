export default {
    // http://49.234.38.240:11001/exter/manage/statisticsJC 统计警察、公司人数的接
};
